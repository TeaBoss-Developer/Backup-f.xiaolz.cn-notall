
from flask import Flask, jsonify
import random
a = 0
app = Flask(__name__)
list1 = ["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","1","2","3","4","5","6","7","8","9","0","@","!","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]
@app.route('/', methods=['GET'])
def home():
    b = ""
    a = 0
    i = 1;
    while i<=5:
        a=0
        while a <=5:
            rad = random.choice(list1)
            a += 1
            b += rad
        if(i<5):
            b+="-"
        i+=1
    return(b)
if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5862)
