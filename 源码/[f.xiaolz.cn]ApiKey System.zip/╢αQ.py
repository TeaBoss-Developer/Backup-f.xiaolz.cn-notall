from flask import Flask, jsonify
import random
import os
from flask import Flask, jsonify
from flask import request
import json
import re
import requests
from datetime import datetime
import os.path
from motime import gettime,time_alert
a = 0
app = Flask(__name__)
@app.route('/', methods=['GET'])
def home():
    try:
        mode = request.args.get("mode",default="read")
        time = request.args.get("time",default="30")
        km = request.args.get("km",default="")
        txt = request.args.get("txt",default="")
        qq=request.args.get("qq",default="")
        code=request.args.get("code",default="")
        s = int(time)
        if (mode == "reg"):
            if(os.path.exists(km+".txt")==True):
                txt = open(km+"机器码.txt",'r')
                t = txt.read()
                txt.close()
                time_time = open(km+".txt",'r')
                tm = time_time.read()
                time_time.close()
                ztzt = open(km+"状态.txt",'r')
                zt = ztzt.read()
                ztzt.close()
                if(t == "None"):
                    addxt = open(km+"机器码.txt",'w')
                    addxt.write(code)
                    addxt.close()
                    if(zt == "0"):
                        addtt = open(km+"状态.txt",'w')
                        addtt.write("1")
                        addtt.close()
                        addtxt = open(km+".txt",'w')
                        addtxt.write(str((int(gettime()))+(int(tm)*(24*3600))))
                        addtxt.close()
                        return("complete")
        if (mode == "add"):
            rl = "http://127.0.0.1:5862"
            rr = requests.get(rl)
            br = rr.text
            ur = str(br)
            if(os.path.exists(ur+".txt")==False):
                addtxt = open(ur+".txt",'a')
                addtxt.write(time)
                addtxt.close()
                txt = open(ur+"机器码.txt",'a')
                txt.write("None")
                txt.close()
                txt = open(ur+"状态.txt",'a')
                txt.write("0")
                txt.close()
                return("添加:"+br+"成功"+"\n"+"时间为:"+time+"天")
        if (mode == "addtxt"):
            rl = "http://127.0.0.1:5862"
            rr = requests.get(rl)
            br = rr.text
            ur = str(br)
            if(os.path.exists(ur+".txt")==False):
                addtxt = open(ur+".txt",'a')
                addtxt.write(txt)
                addtxt.close()
                return("添加:"+br+"成功"+"\n"+"内容为:"+txt)
        if(mode=="readtxt"):
            if (km == ""):
                return("卡密不得为空")
            else:
                readtxt = open(km+".txt",'r')
                aaa = readtxt.readline()
                readtxt.close()
                return (aaa)
        if(mode=="read"):
            if(km==""):
                return("卡密不得为空")
            else:
                if(os.path.exists(km+".txt")==True):
                    readtxt = open(km+".txt",'r')
                    aaa = readtxt.readline()
                    readtxt.close()
                    txt = open(km+"机器码.txt",'r')
                    ma = txt.read()
                    txt.close()
                    return(time_alert(gettime(),aaa)+" "+ma)
                else:
                    return("卡密错误")
    except:
        return "运行错误"
if __name__ == '__main__':
    app.run(host="0.0.0.0", port=6001)
