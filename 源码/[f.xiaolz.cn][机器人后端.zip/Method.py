import socket
import os
import configparser

class Method:
    def ReadIni(config_path,section,Param,value=""):#读配置项
        conf = configparser.ConfigParser()
        try:
            conf.read(config_path)
        except:
            return("发现问题,配置文件中拥有两个相同的配置节.")
        try:
            return(conf.get(section,Param))
        except:
            return("")
    def WriteIni(config_path,section,Param,value):#写配置项
        conf = configparser.ConfigParser()
        conf.read(config_path)
        try:
            conf.set(section,Param,value)
        except:
            conf.add_section(section)
            conf.set(section,Param,value)
        conf.write(open(config_path,'w+'))
        return(config_path+"  "+section+"  "+Param+"  "+value)
    def RunPath():#取运行目录
        proDir = os.path.split(os.path.realpath(__file__))[0]
        return(proDir)
    def Socket(IP,Port,msg):
        ADDR = (IP,int(Port))
        tcpCliSock = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
        tcpCliSock.connect(ADDR)
        tcpCliSock.sendall(msg.encode('utf-8'))
        data1 = tcpCliSock.recv(1024)
        tcpCliSock.close()
        return(data1.decode('utf-8'))
class 方法:
    def 读配置项(config_path,section,Param,value=""):#读配置项
        conf = configparser.ConfigParser()
        try:
            conf.read(config_path)
        except:
            return("发现问题,配置文件中拥有两个相同的配置节.")
        return(conf.get(section,Param))
    def 写配置项(config_path,section,Param,value):#写配置项
        conf = configparser.ConfigParser()
        conf.read(config_path)
        try:
            conf.set(section,Param,value)
        except:
            conf.add_section(section)
            conf.set(section,Param,value)
        conf.write(open(config_path,'w+'))
        return(config_path+"  "+section+"  "+Param+"  "+value)
    def 取运行目录():#取运行目录
        proDir = os.path.split(os.path.realpath(__file__))[0]
        return(proDir)