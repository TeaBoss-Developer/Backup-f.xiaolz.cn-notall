from email import message
from tokenize import group
import requests
import json
se = requests.session()

def Json_解析(msg,key):
    jsons = json.loads(msg, strict=False)
    return(str(jsons[key]))

class Texts:#文本代码类(SA:@at)
    def 表情(id_):
        return("[CQ:face,id="+id_+"]")
    def 录音(file_url):
        return("[CQ:record,file="+file_url+"]")
    def 艾特(user_id):
        return("[CQ:at,qq="+user_id+"]")
    def 分享(url,title):
        return("[CQ:share,url="+url+",title="+title+"]")
    def 图片(file,_type,url,_id):
        return("[CQ:image,file="+url+",type="+_type+",id="+_id+"]")
    def 红包(title):
        return("[CQ:redbag,title="+title+"]")
    def 戳一戳(qq):
        return("[CQ:poke,qq="+qq+"]")
    def xml(data):
        return("[CQ:xml,data="+data+"]")
    def json(data):
        bufo = data.replace(",","&#44;")
        buft = bufo.replace("&","&amp;")
        bufth = buft.replace("[","&#91;")
        buff = bufth.replace("]","&#93")
        return("[CQ:json,data="+buff+"]")
    def tts语音(text):
        return("[CQ:tts,text="+text+"]")
    def python(code):
        try:
            return(exec(code))
        except Exception as error:
            a = str(type(error))
            err = a.split("class '")[1].split("'")[0]
            return(err+":"+str(error))
class Api:#API类(SA:好友消息,群消息.)
    def 发送好友消息(private_id,msg):
        Post_url = "http://127.0.0.1:5700/send_private_msg?user_id="+private_id+"&message="+msg
        Text = se.post(Post_url).text.replace("'", '"').replace('/ ', '/')
        print(Text)
    def 发送群消息(group_id,msg):
        Post_url = "http://127.0.0.1:5700/send_group_msg?group_id="+group_id+"&message="+msg
        Text = se.post(Post_url).text.replace("'", '"').replace('/ ', '/')
        print(Text)
    def 撤回信息(msg_id):
        Post_url = "http://127.0.0.1:5700/delete_msg?message_id="+msg_id
        Text = se.post(Post_url).text.replace("'", '"').replace('/ ', '/')
        print(Text)
    def 踢出群聊(group_id,user_id,boolean):
        Post_url = "http://127.0.0.1:5700/set_group_kick?group_id="+group_id+"&user_id="+user_id+"&reject_add_request="+boolean
        Text = se.post(Post_url).text.replace("'", '"').replace('/ ', '/')
        print(Text)
    def 群禁言(group_id,user_id,time):
        Post_url = "http://127.0.0.1:5700/set_group_ban?group_id="+group_id+"&user_id="+user_id+"&duration="+time
        Text = se.post(Post_url).text.replace("'", '"').replace('/ ', '/')
        print(Text)
    def 开启全体禁言(group_id,boolean):
        Post_url = "http://127.0.0.1:5700/set_group_whole_ban?group_id="+group_id+"&enable="+boolean
        Text = se.post(Post_url).text.replace("'", '"').replace('/ ', '/')
        print(Text)
    def 设置管理员(group_id,user_id,boolean):
        Post_url = "http://127.0.0.1:5700/set_group_admin?group_id="+group_id+"&user_id="+user_id+"&enable="+boolean
        Text = se.post(Post_url).text.replace("'", '"').replace('/ ', '/')
        print(Text)
    def 设置群名片(group_id,user_id,rank):
        Post_url = "http://127.0.0.1:5700/set_group_card?group_id="+group_id+"&user_id="+user_id+"&card="+rank
        Text = se.post(Post_url).text.replace("'", '"').replace('/ ', '/')
        print(Text)
    def 退出群聊(group_id,is_dismiss):
        Post_url = "http://127.0.0.1:5700/set_group_leave?group_id="+group_id+"&is_dismiss="+is_dismiss
        Text = se.post(Post_url).text.replace("'", '"').replace('/ ', '/')
        print(Text)
    def 设置特殊头衔(group_id,uesr_id,special_title):
        Post_url = "http://127.0.0.1:5700/set_group_special_title?group_id="+group_id+"&user_id="+uesr_id+"&special_title="+special_title
        Text = se.post(Post_url).text.replace("'", '"').replace('/ ', '/')
        print(Text)
    def 同意好友请求(flag,approve,remark):
        Post_url = "http://127.0.0.1:5700/set_friend_add_request?flag="+flag+"&approve="+approve+"&remark="+remark
        Text = se.post(Post_url).text.replace("'", '"').replace('/ ', '/')
        print(Text)
    def 同意群邀请(flag,sub_type,approve,reason):
        Post_url = "http://127.0.0.1:5700/set_group_add_request?flag="+flag+"&approve="+approve+"&reason="+reason+"&sub_type="+sub_type
        Text = se.post(Post_url).text.replace("'", '"').replace('/ ', '/')
        print(Text)
    def 取框架QQ():
        Post_url = "http://127.0.0.1:5700/get_login_info"
        Text = se.post(Post_url).text.replace("'", '"').replace('/ ', '/')
        return(Text)
    def 取陌生人信息(user_id):
        Post_url = "http://127.0.0.1:5700/get_stranger_info?user_id="+user_id
        Text = se.post(Post_url).text.replace("'", '"').replace('/ ', '/')
        return(Text)
    def 删除好友(friend_id):
        Post_url = "http://127.0.0.1:5700/delete_friend?friend_id="+friend_id
        Text = se.post(Post_url).text.replace("'", '"').replace('/ ', '/')
        print(Text)
    def 获取群信息(group_id):
        Post_url = "http://127.0.0.1:5700/get_group_info?group_id="+group_id
        Text = se.post(Post_url).text.replace("'", '"').replace('/ ', '/')
        print(Text)
    def 取好友列表():
        Post_url = "http://127.0.0.1:5700/get_friend_list"
        Text = se.post(Post_url).text.replace("'", '"').replace('/ ', '/')
        return(Text)
    def 取群列表():
        Post_url = "http://127.0.0.1:5700/get_group_list"
        Text = se.post(Post_url).text.replace("'", '"').replace('/ ', '/')
        return(Text)
    def 取群员消息(group_id,user_id):
        Post_url = "http://127.0.0.1:5700/get_group_member_info?group_id="+group_id+"&user_id="+user_id
        Text = se.post(Post_url).text.replace("'", '"').replace('/ ', '/')
        return(Text)
    def 取群成员列表(group_id):
        Post_url = "http://127.0.0.1:5700/get_group_member_list?group_id="+group_id
        Text = se.post(Post_url).text.replace("'", '"').replace('/ ', '/')
        return(Text)
    def 重启机器人(delay):
        Post_url = "http://127.0.0.1:5700/set_restart?delay="+delay
        Text = se.post(Post_url).text.replace("'", '"').replace('/ ', '/')
        print(Text)
    def 设置精华消息(message_id):
        Post_url = "http://127.0.0.1:5700/set_essence_msg?message_id="+message_id
        Text = se.post(Post_url).text.replace("'", '"').replace('/ ', '/')
        print(Text)
    def 删精华消息(message_id):
        Post_url = "http://127.0.0.1:5700/delete_essence_msg?message_id="+message_id
        Text = se.post(Post_url).text.replace("'", '"').replace('/ ', '/')
        print(Text)
    def 设置在线机型(modle,modle_show):
        Post_url = "http://127.0.0.1:5700/_set_model_show?model="+modle+"&modle_show="+modle_show
        Text = se.post(Post_url).text.replace("'", '"').replace('/ ', '/')
        print("具体机型在这个链接里查看:https://github.com/Mrs4s/go-cqhttp/pull/872#issuecomment-831180149")
    def 发布群公告(group_id,content,image_path):
        Post_url = "http://127.0.0.1:5700/_send_group_notice?group_id="+group_id+"&content="+content+"&image="+image_path
        Text = se.post(Post_url).text.replace("'", '"').replace('/ ', '/')
        print(Text)
    def 上传群文件():
        print("开发中,请敬请等待.")
    def 取群系统消息():
        Post_url = "http://127.0.0.1:5700/get_group_system_msg"
        Text = se.post(Post_url).text.replace("'", '"').replace('/ ', '/')
        return(Text)
    def 设置群头像(group_id,file,cache):
        Post_url = "http://127.0.0.1:5700/set_group_portrait?group_id="+group_id+"&file="+file+"&cache="+cache
        Text = se.post(Post_url).text.replace("'", '"').replace('/ ', '/')
        print("具体操作file可以为什么数据请看https://docs.go-cqhttp.org/api/#%E8%AE%BE%E7%BD%AE%E7%BE%A4%E5%A4%B4%E5%83%8F")
class 消息数据:
    post_type =""
    message_type = ""
    sub_type = ""
    message_id = ""
    user_id = ""
    message = ""
    raw_message = ""
    font = ""
    sender = ""
    temp_source = ""
    group_id = ""
    self_id = ""
    time = ""
    def __init__(self,msg):
        self.message = Json_解析(msg,"message")
        self.post_type = Json_解析(msg,"post_type")
        self.message_type = Json_解析(msg,"message_type")
        self.sub_type = Json_解析(msg,"sub_type")
        self.message_id = Json_解析(msg,"message_id")
        self.user_id = Json_解析(msg,"user_id")
        self.message = Json_解析(msg,"message")
        self.raw_message = Json_解析(msg,"raw_message")
        self.sender = Json_解析(msg,"sender")
        self.self_id = Json_解析(msg,"self_id")
        self.time = Json_解析(msg,"time")
        if("temp_source" in msg):
            self.temp_source = Json_解析(msg,"temp_source")
        if(self.message_type == "group"):
            self.group_id = Json_解析(msg,"group_id")

class 群消息_撤回:
    group_id = ""
    sender = ""
    msg_id = ""
    def __init__(self,msg1):
        qhz = msg1.split("\"group_id\":")
        qhy = qhz[1].split(",\"message_id\":")
        SQz = msg1.split("\"user_id\":")
        sq = SQz[1].split("}")
        xxz = msg1.split("\"message_id\":")
        xxm = xxz[1].split(",\"notice_type\"")
        self.group_id=qhy[0]
        self.msg_id=xxm[0]
        self.sender=sq[0]
class 群禁言:
    group_id = ""
    time = ""
    operator_id = ""
    user_id = ""
    def __init__(self,msg1):
        qhz = msg1.split("\"group_id\":")
        qhy = qhz[1].split(",\"notice_type\"")
        sjz = msg1.split("\"duration\":")
        sjy = sjz[1].split(",\"group_id")
        czz = msg1.split("\"operator_id\":")
        czy = czz[1].split(",\"post_type")
        bez = msg1.split("\"user_id\":")
        bey = bez[1].split("}")
        self.group_id = qhy[0]
        self.operator_id = czy[0]
        self.time = sjy[0]
        self.user_id = bey[0]
class 好友撤回:
    user_id = ""
    message_id =""
    def __init__(self,msg1):
        self.message_id = Json_解析(msg1,"message_id")
        self.user_id = Json_解析(msg1,"user_id")
class 群管理:
    group_id = ""
    sub_type = ""
    user_id = ""
    def __init__(self,msg1):
        qhz = msg1.split("\"group_id\":")
        qhy = qhz[1].split(",\"notice_type\"")
        setz = msg1.split("\"sub_type\":\"")
        sety = setz[1].split("\",\"time\"")
        bez = msg1.split("\"user_id\":")
        bey = bez[1].split("}")
        self.group_id = qhy[0]
        self.sub_type = sety[0]
        self.user_id = bey[0]
class 群邀请:
    flag = ""
    group_id = ""
    self_id = ""
    user_id = ""
    def __init__(self,msg1):
        self.flag = Json_解析(msg1,"flag")
        self.group_id = Json_解析(msg1,"group_id")
        self.self_id = Json_解析(msg1,"self_id")
        self.user_id = Json_解析(msg1,"user_id")
class 好友请求:
    time = ""
    self_id = ""
    post_type = ""
    request_type = ""
    user_id = ""
    comment = ""
    flag = ""
    def __init__(self,msg):
        self.flag = Json_解析(msg,"flag")
        self.group_id = Json_解析(msg,"group_id")
        self.self_id = Json_解析(msg,"self_id")
        self.user_id = Json_解析(msg,"user_id") 
        self.comment = Json_解析(msg,"comment")
class 其他_事件:
    time = ""
    self_id = ""
    post_type = ""#判断事件父类型
    notice_type = ""#上报事件类型
    user_id = ""
    group_id = ""
    file = ""
    sub_type = "" #判断事件子类型
    operator_id = ""#操作者
    duration = "" #禁言时间
    message_id = ""
    sender_id = ""#Same to User_id
    target_id = ""#目标(一般为戳一戳)
    honor_type = ""#荣誉(一般为龙王等内容)
    card_new = ""
    card_old = ""
    client = ""
    online = ""
    def __init__(self,msg):
        self.time = Json_解析(msg,"time")
        self.self_id = Json_解析(msg,"self_id")
        self.post_type = Json_解析(msg,"post_type")
        self.notice_type = Json_解析(msg,"notice_type")
        if(self.notice_type == "group_upload"):
            self.group_id = Json_解析(msg,"group_id")
            self.user_id = Json_解析(msg,"user_id")
            self.file = Json_解析(msg,"file")
        if(self.notice_type == "group_decrease" or self.notice_type == "group_increase"):
            self.sub_type = Json_解析(msg,"sub_type")
            self.group_id = Json_解析(msg,"group_id")
            self.operator_id = Json_解析(msg,"operator_id")
            self.user_id = Json_解析(msg,"user_id")
        if(self.notice_type == "group_ban"):
            self.sub_type = Json_解析(msg,"sub_type")
            self.group_id = Json_解析(msg,"group_id")
            self.operator_id = Json_解析(msg,"operator_id")
            self.user_id = Json_解析(msg,"user_id")
            self.duration = Json_解析(msg,"duration")
        if(self.notice_type == "friend_add"):
            self.user_id = Json_解析(msg,"user_id")
        if(self.notice_type == "notify"):
            self.user_id = Json_解析(msg,"user_id")
            self.sub_type = Json_解析(msg,"sub_type")
            self.target_id = Json_解析(msg,"target_id")
            if("group_id" in msg):
                self.group_id = Json_解析(msg,"group_id")
        if("lucky_king" in msg):
            self.user_id = Json_解析(msg,"user_id")
            self.sub_type = Json_解析(msg,"sub_type")
            self.target_id = Json_解析(msg,"target_id")
            self.group_id = Json_解析(msg,"group_id")
        if("honor_type" in msg):
            self.user_id = Json_解析(msg,"user_id")
            self.sub_type = Json_解析(msg,"sub_type")
            self.honor_type = Json_解析(msg,"honor_type")
            self.group_id = Json_解析(msg,"group_id")
        if(self.notice_type == "group_card"):
            self.group_id = Json_解析(msg,"group_id")
            self.user_id = Json_解析(msg,"user_id")
            self.card_new = Json_解析(msg,"card_new")
            self.card_old = Json_解析(msg,"card_old")
        if(self.notice_type == "offline_file"):
            self.user_id = Json_解析(msg,"user_id")
            self.file = Json_解析(msg,"file")
        if(self.notice_type == "client_status"):
            self.client = Json_解析(msg,"client")
            self.online = Json_解析(msg,"online")
        if(self.notice_type == "essence"):
            self.sub_type = Json_解析(msg,"sub_type")
            self.sender_id= Json_解析(msg,"sender_id")
            self.operator_id = Json_解析(msg,"operator_id")
            self.message_id = Json_解析(msg,"message_id")