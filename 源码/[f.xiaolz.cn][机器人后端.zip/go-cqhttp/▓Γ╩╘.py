from encodings import utf_8
import yaml

yamls = open("W:\\[机器人前端\\go-cqhttp\\config.yml","r", encoding='utf-8')

xl = yaml.safe_load(yamls)

print(xl)