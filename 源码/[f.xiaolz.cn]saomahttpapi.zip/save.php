<?php
header("Content-type: text/html; charset=utf-8");////需要配置的地方：第3、4、24、44行
$url='';//api地址 格式： http://ip:端口/
$User = ""; //HTTP Api插件创建的用户名
$qqlj = "qqlist_getqrcode_login"; //已设置好，不用再修改
$shoubiao ='addqq';//已设置好，不用再修改
$Timestamp = time();
if ($username=$_POST["username"])//已设置好，不用再修改
{
$curl = curl_init();//已设置好，不用再修改
curl_setopt_array($curl, array(
  CURLOPT_URL => $url.$shoubiao,
  CURLOPT_RETURNTRANSFER => true, 
  CURLOPT_ENCODING => 'gzip,deflate', 
  CURLOPT_MAXREDIRS => 10, 
  CURLOPT_TIMEOUT => 30, 
  CURLOPT_FOLLOWLOCATION => true, 
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1, 
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS => array('logonqq' => $username ,'protocol' => '6'),
  CURLOPT_HTTPHEADER => array( 
    'H-Auth-User: '.$User,
    'H-Auth-Timestamp: '.$Timestamp,
    'H-Auth-Signature: '.md5($User."/".$shoubiao.md5("用户密码").$Timestamp)//HTTP Api插件创建的密码
  ),
));
$response = curl_exec($curl);
//curl_close($curl);
sleep(0.5);//延迟执行，因为httpapi不支持无账号添加所以延迟请求在拉取
//$curl = curl_init();
  curl_setopt_array($curl, array(
    CURLOPT_URL => $url.$qqlj,
    CURLOPT_RETURNTRANSFER => true, 
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1, 
    CURLOPT_CUSTOMREQUEST => 'POST',
    CURLOPT_POSTFIELDS => array('logonqq' => $username),
    CURLOPT_HTTPHEADER => array( 
      'H-Auth-User: '.$User,
      'H-Auth-Timestamp: '.$Timestamp,
      'H-Auth-Signature: '.md5($User."/".$qqlj.md5("用户密码").$Timestamp)//HTTP Api插件创建的密码
    ),
  ));
  $response = curl_exec($curl);
  curl_close($curl);
  $json = json_decode($response,true);
  $jpg = 'data:image/jpg;base64,' . $json['data']; 
  echo '<img src="' . $jpg . '" height="180" width="180"/>';
}
else
{
    echo "登录失败请联系管理员！";
}



?>